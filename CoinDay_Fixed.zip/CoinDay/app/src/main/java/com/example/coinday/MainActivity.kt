package com.example.coinday

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Operation(
    val id: Long, val type: String, val amount: Double,
    val category: String, val date: String, val note: String
)
data class Goal(val id: Long, val name: String, val target: Double, val saved: Double)

class CoinDatabase(context: android.content.Context) :
    SQLiteOpenHelper(context, "coinday.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE operations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL, amount REAL NOT NULL, category TEXT NOT NULL,
            date TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')""")
        db.execSQL("""CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE goals(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            target REAL NOT NULL, saved REAL NOT NULL DEFAULT 0)""")
        db.execSQL("INSERT INTO settings(key,value) VALUES('budget','20000')")
        db.execSQL("INSERT INTO goals(name,target,saved) VALUES('Новый ноутбук',60000,12000)")
        db.execSQL("INSERT INTO goals(name,target,saved) VALUES('Путешествие',30000,5000)")
        // Small demo data helps the statistics screen look populated.
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        db.execSQL("INSERT INTO operations(type,amount,category,date,note) VALUES('income',45000,'Зарплата',?,'Зарплата за месяц')", arrayOf(today))
        db.execSQL("INSERT INTO operations(type,amount,category,date,note) VALUES('expense',850,'Еда',?,'Обед')", arrayOf(today))
        db.execSQL("INSERT INTO operations(type,amount,category,date,note) VALUES('expense',320,'Транспорт',?,'Проезд')", arrayOf(today))
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addOperation(type: String, amount: Double, category: String, date: String, note: String) {
        val values = ContentValues().apply {
            put("type", type); put("amount", amount); put("category", category)
            put("date", date); put("note", note)
        }
        writableDatabase.insert("operations", null, values)
    }
    fun allOperations(): List<Operation> {
        val list = mutableListOf<Operation>()
        readableDatabase.rawQuery("SELECT id,type,amount,category,date,note FROM operations ORDER BY date DESC,id DESC", null)
            .use { c ->
                while (c.moveToNext()) list.add(Operation(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3), c.getString(4), c.getString(5)))
            }
        return list
    }
    fun operation(id: Long): Operation? = allOperations().firstOrNull { it.id == id }
    fun deleteOperation(id: Long) { writableDatabase.delete("operations", "id=?", arrayOf(id.toString())) }
    fun updateOperation(id: Long, type: String, amount: Double, category: String, date: String, note: String) {
        val values = ContentValues().apply {
            put("type", type); put("amount", amount); put("category", category); put("date", date); put("note", note)
        }
        writableDatabase.update("operations", values, "id=?", arrayOf(id.toString()))
    }
    fun budget(): Double {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key='budget'", null).use {
            return if (it.moveToFirst()) it.getString(0).toDoubleOrNull() ?: 20000.0 else 20000.0
        }
    }
    fun setBudget(value: Double) {
        val v = ContentValues().apply { put("key", "budget"); put("value", value.toString()) }
        writableDatabase.insertWithOnConflict("settings", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun goals(): List<Goal> {
        val list = mutableListOf<Goal>()
        readableDatabase.rawQuery("SELECT id,name,target,saved FROM goals ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) list.add(Goal(c.getLong(0), c.getString(1), c.getDouble(2), c.getDouble(3)))
        }
        return list
    }
    fun addGoal(name: String, target: Double) {
        val v = ContentValues().apply { put("name", name); put("target", target); put("saved", 0.0) }
        writableDatabase.insert("goals", null, v)
    }
    fun addToGoal(id: Long, amount: Double) {
        writableDatabase.execSQL("UPDATE goals SET saved=saved+? WHERE id=?", arrayOf(amount, id))
    }
    fun deleteAll() {
        writableDatabase.delete("operations", null, null)
        writableDatabase.delete("goals", null, null)
    }
}

class MainActivity : Activity() {
    private lateinit var db: CoinDatabase
    private lateinit var root: LinearLayout
    private val green = Color.rgb(36, 122, 88)
    private val dark = Color.rgb(25, 55, 47)
    private val pale = Color.rgb(239, 247, 242)
    private val gray = Color.rgb(105, 115, 110)
    private val currency = " ₽"
    private var selectedOperationId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CoinDatabase(this)
        showHome()
    }

    private fun money(n: Double) = String.format(Locale("ru", "RU"), "%,.2f", n).replace(',', ' ').replace('.', ',') + currency
    private fun all() = db.allOperations()
    private fun income() = all().filter { it.type == "income" }.sumOf { it.amount }
    private fun expenses() = all().filter { it.type == "expense" }.sumOf { it.amount }
    private fun balance() = income() - expenses()
    private fun monthExpenses() = all().filter { it.type == "expense" && it.date.startsWith(SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())) }.sumOf { it.amount }

    private fun page(title: String, subtitle: String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 250, 248))
            setPadding(dp(18), dp(18), dp(18), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(14)) }
        top.addView(TextView(this).apply { text = title; textSize = 26f; setTextColor(dark); typeface = Typeface.DEFAULT_BOLD })
        if (subtitle != null) top.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(gray); setPadding(0, dp(4), 0, 0) })
        content.addView(top)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        listOf("Главная", "Операции", "Бюджет", "Статистика", "Ещё").forEach { label ->
            val b = Button(this).apply {
                text = label; textSize = 10f; isAllCaps = false
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener {
                    when (label) {
                        "Главная" -> showHome()
                        "Операции" -> showOperations()
                        "Бюджет" -> showBudget()
                        "Статистика" -> showStatistics()
                        else -> showMore()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        setContentView(root)
        return content
    }

    private fun addText(parent: LinearLayout, text: String, size: Float = 16f, color: Int = dark, bold: Boolean = false) {
        parent.addView(TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, dp(5))
        })
    }
    private fun card(parent: LinearLayout, title: String, detail: String, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.WHITE)
            elevation = dp(1).toFloat()
        }
        addText(box, title, 16f, dark, true)
        addText(box, detail, 14f, gray)
        if (action != null) box.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        parent.addView(box, lp)
    }
    private fun button(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { action() } }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(7)
        parent.addView(b, lp)
    }
    private fun field(parent: LinearLayout, hint: String, initial: String = ""): EditText {
        val e = EditText(this).apply { this.hint = hint; setText(initial); textSize = 16f }
        parent.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun showHome() {
        val c = page("CoinDay", "Твои финансы под контролем")
        card(c, "Текущий баланс", money(balance()))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val col1 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(pale) }
        val col2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(Color.rgb(255, 241, 238)) }
        addText(col1, "Доходы", 14f, gray); addText(col1, money(income()), 17f, green, true)
        addText(col2, "Расходы", 14f, gray); addText(col2, money(expenses()), 17f, Color.rgb(190, 70, 60), true)
        row.addView(col1, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        row.addView(col2, LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(row)
        addText(c, "Бюджет на месяц", 18f, dark, true)
        addText(c, "Потрачено: ${money(monthExpenses())} из ${money(db.budget())}")
        val remaining = db.budget() - monthExpenses()
        addText(c, "Осталось: ${money(remaining)}", 15f, if (remaining >= 0) green else Color.RED, true)
        button(c, "+ Добавить расход") { showAddOperation("expense") }
        button(c, "+ Добавить доход") { showAddOperation("income") }
        addText(c, "Последние операции", 18f, dark, true)
        all().take(4).forEach { op ->
            card(c, "${if (op.type == "income") "+" else "−"}${money(op.amount)} · ${op.category}", "${op.date}${if (op.note.isNotBlank()) " · ${op.note}" else ""}") { showOperationDetails(op.id) }
        }
    }

    private fun showOperations() {
        val c = page("Все операции", "Нажми на запись, чтобы посмотреть подробности")
        button(c, "+ Добавить расход") { showAddOperation("expense") }
        button(c, "+ Добавить доход") { showAddOperation("income") }
        val ops = all()
        if (ops.isEmpty()) addText(c, "Пока нет операций. Добавь первый доход или расход.")
        ops.forEach { op ->
            val sign = if (op.type == "income") "+" else "−"
            card(c, "$sign${money(op.amount)} · ${op.category}", "${op.date}${if (op.note.isNotBlank()) " · ${op.note}" else ""}") { showOperationDetails(op.id) }
        }
    }

    private fun showAddOperation(type: String, existing: Operation? = null) {
        val isIncome = type == "income"
        val c = page(if (existing == null) if (isIncome) "Добавить доход" else "Добавить расход" else "Редактировать операцию")
        addText(c, "Сумма (рубли)")
        val amount = field(c, "Например, 1250,50", existing?.amount?.toString() ?: "")
        addText(c, "Категория")
        val categories = if (isIncome) arrayOf("Зарплата", "Подработка", "Подарок", "Другое") else arrayOf("Еда", "Транспорт", "Жильё", "Покупки", "Здоровье", "Развлечения", "Другое")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        existing?.let { op -> val ix = categories.indexOf(op.category); if (ix >= 0) spinner.setSelection(ix) }
        c.addView(spinner)
        addText(c, "Дата (ГГГГ-ММ-ДД)")
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val date = field(c, "2026-10-28", existing?.date ?: today)
        addText(c, "Комментарий")
        val note = field(c, "Например, продукты на неделю", existing?.note ?: "")
        button(c, "Сохранить") {
            val value = amount.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (value == null || value <= 0) {
                amount.error = "Введи сумму больше нуля"
                return@button
            }
            val d = date.text.toString().trim()
            if (!d.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                date.error = "Используй формат ГГГГ-ММ-ДД"
                return@button
            }
            if (existing == null) db.addOperation(type, value, spinner.selectedItem.toString(), d, note.text.toString().trim())
            else db.updateOperation(existing.id, type, value, spinner.selectedItem.toString(), d, note.text.toString().trim())
            showHome()
        }
        button(c, "Отмена") { if (existing == null) showOperations() else showOperationDetails(existing.id) }
    }

    private fun showOperationDetails(id: Long) {
        val op = db.operation(id) ?: run { showOperations(); return }
        val c = page("Подробности операции")
        addText(c, if (op.type == "income") "Доход" else "Расход", 15f, gray)
        addText(c, money(op.amount), 28f, if (op.type == "income") green else Color.rgb(190, 70, 60), true)
        card(c, "Категория", op.category)
        card(c, "Дата", op.date)
        card(c, "Комментарий", op.note.ifBlank { "Нет комментария" })
        button(c, "Редактировать") { showAddOperation(op.type, op) }
        button(c, "Удалить операцию") {
            AlertDialog.Builder(this).setTitle("Удалить операцию?")
                .setMessage("Баланс и статистика будут пересчитаны.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить") { _, _ -> db.deleteOperation(id); showOperations() }.show()
        }
    }

    private fun showCategories() {
        val c = page("Категории", "Категории для выбора при добавлении операции")
        addText(c, "Расходы", 18f, dark, true)
        listOf("Еда", "Транспорт", "Жильё", "Покупки", "Здоровье", "Развлечения", "Другое").forEach { name ->
            val sum = all().filter { it.type == "expense" && it.category == name }.sumOf { it.amount }
            card(c, name, "Всего: ${money(sum)}")
        }
        addText(c, "Доходы", 18f, dark, true)
        listOf("Зарплата", "Подработка", "Подарок", "Другое").forEach { name ->
            val sum = all().filter { it.type == "income" && it.category == name }.sumOf { it.amount }
            card(c, name, "Всего: ${money(sum)}")
        }
        addText(c, "В этой учебной версии используются готовые категории.")
    }

    private fun showBudget() {
        val c = page("Месячный бюджет", "Установи лимит расходов на месяц")
        val limit = db.budget()
        val spent = monthExpenses()
        val left = limit - spent
        card(c, "Лимит", money(limit))
        card(c, "Потрачено в этом месяце", money(spent))
        card(c, "Остаток", money(left))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progress = if (limit > 0) (spent / limit * 100).toInt().coerceIn(0, 100) else 0
        c.addView(bar, LinearLayout.LayoutParams(-1, dp(20)))
        addText(c, "Использовано ${bar.progress}% бюджета")
        button(c, "Изменить бюджет") {
            val input = EditText(this).apply { inputType = 8194; setText(db.budget().toString()); hint = "Сумма в рублях" }
            AlertDialog.Builder(this).setTitle("Месячный бюджет").setView(input)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить") { _, _ ->
                    val v = input.text.toString().replace(',', '.').toDoubleOrNull()
                    if (v != null && v > 0) { db.setBudget(v); showBudget() }
                    else Toast.makeText(this, "Введи сумму больше нуля", Toast.LENGTH_SHORT).show()
                }.show()
        }
    }

    private fun showStatistics() {
        val c = page("Статистика", "Сводка по всем сохранённым операциям")
        card(c, "Все доходы", money(income()))
        card(c, "Все расходы", money(expenses()))
        card(c, "Разница", money(balance()))
        addText(c, "Расходы по категориям", 18f, dark, true)
        val cats = all().filter { it.type == "expense" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
        if (cats.isEmpty()) addText(c, "Добавь расходы, чтобы увидеть статистику.")
        cats.forEach { (name, sum) ->
            val total = expenses().coerceAtLeast(1.0)
            val percent = (sum / total * 100).toInt()
            card(c, name, "${money(sum)} · $percent% от расходов")
        }
        addText(c, "Статистика пересчитывается на основе сохранённых операций.")
    }

    private fun showHistory() {
        val c = page("История", "Все операции по дате")
        val grouped = all().groupBy { it.date }
        if (grouped.isEmpty()) addText(c, "История пока пуста.")
        grouped.toSortedMap(compareByDescending { it }).forEach { (date, ops) ->
            addText(c, date, 18f, dark, true)
            ops.forEach { op -> card(c, "${if (op.type == "income") "+" else "−"}${money(op.amount)} · ${op.category}", op.note.ifBlank { "Без комментария" }) { showOperationDetails(op.id) } }
        }
    }

    private fun showGoals() {
        val c = page("Цели накопления", "Откладывай деньги на то, что важно")
        button(c, "+ Создать цель") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
            val name = field(box, "Название цели")
            val target = field(box, "Необходимая сумма")
            AlertDialog.Builder(this).setTitle("Новая цель").setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Создать") { _, _ ->
                    val n = name.text.toString().trim()
                    val t = target.text.toString().replace(',', '.').toDoubleOrNull()
                    if (n.isNotBlank() && t != null && t > 0) { db.addGoal(n, t); showGoals() }
                    else Toast.makeText(this, "Заполни название и корректную сумму", Toast.LENGTH_SHORT).show()
                }.show()
        }
        db.goals().forEach { goal ->
            val percent = if (goal.target > 0) (goal.saved / goal.target * 100).toInt().coerceIn(0, 100) else 0
            card(c, goal.name, "Накоплено ${money(goal.saved)} из ${money(goal.target)}")
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100; bar.progress = percent
            c.addView(bar, LinearLayout.LayoutParams(-1, dp(18)))
            addText(c, "$percent% выполнено")
            button(c, "Пополнить цель") { showAddToGoal(goal.id, goal.name) }
        }
    }

    private fun showAddToGoal(id: Long, name: String) {
        val c = page("Пополнение цели", name)
        val amount = field(c, "Сумма пополнения")
        button(c, "Пополнить") {
            val v = amount.text.toString().replace(',', '.').toDoubleOrNull()
            if (v == null || v <= 0) amount.error = "Введи сумму больше нуля"
            else { db.addToGoal(id, v); showGoals() }
        }
        button(c, "Назад") { showGoals() }
    }

    private fun showSettings() {
        val c = page("Настройки", "Настрой приложение под себя")
        card(c, "Валюта", "Российский рубль (₽)")
        card(c, "Тема", "Светлая тема")
        button(c, "Сбросить демонстрационные данные") {
            AlertDialog.Builder(this).setTitle("Очистить данные?")
                .setMessage("Удалятся все операции и цели накопления. Бюджет останется прежним.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Очистить") { _, _ -> db.deleteAll(); showHome() }.show()
        }
        addText(c, "CoinDay · учебный проект")
    }

    private fun showMore() {
        val c = page("Ещё", "Дополнительные разделы")
        button(c, "Категории") { showCategories() }
        button(c, "История") { showHistory() }
        button(c, "Цели накопления") { showGoals() }
        button(c, "Настройки") { showSettings() }
        button(c, "Добавить расход") { showAddOperation("expense") }
        button(c, "Добавить доход") { showAddOperation("income") }
    }
}
